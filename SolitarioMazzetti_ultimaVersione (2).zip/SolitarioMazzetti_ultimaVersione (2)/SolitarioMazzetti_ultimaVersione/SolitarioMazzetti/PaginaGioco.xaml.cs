﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SolitarioMazzetti
{
    /// <summary>
    /// Logica di interazione per PaginaGioco.xaml
    /// </summary>
    public partial class PaginaGioco : Page
    {
        //MazzoPrincipale mazzo;
        Gioco gioco;
        Carta cartaScoperta;
       // Mazzetto mazzetto;
        public PaginaGioco()
        {
            
            InitializeComponent();
            btnReplay.Visibility = Visibility.Collapsed;
            string percorso = @"Images\RETRO.jpg";
            
            
            imgDeck.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck1.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck2.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck3.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck4.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck5.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck6.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck7.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck8.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck9.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            btnDeck1.IsEnabled = false;
            btnDeck2.IsEnabled = false;
            btnDeck3.IsEnabled = false;
            btnDeck4.IsEnabled = false;
            btnDeck5.IsEnabled = false;
            btnDeck6.IsEnabled = false; 
            btnDeck7.IsEnabled = false;
            btnDeck8.IsEnabled = false;
            btnDeck9.IsEnabled = false;
            
            //mazzo = new MazzoPrincipale();
            gioco = new Gioco();
            //carta = new Carta();
            //mazzetto= new Mazzetto();
        }
        

        private void btnDeck_Click(object sender, RoutedEventArgs e)
        {
            cartaScoperta = gioco.Mazzo.Mazzetti[0].EstraiPrimaCarta();
            ShowCard(imgDiscoveredCard);
            btnDeck.IsEnabled = false;
            EnableCorrectButton(cartaScoperta);
            gioco.AggiornaSituazionePartita();
        }
        
        public void EnableCorrectButton(Carta cartaScoperta)
        {
            if (cartaScoperta.Valore == 1)
            {
                btnDeck1.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 2)
            {
                btnDeck2.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 3)
            {
                btnDeck3.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 4)
            {
                btnDeck4.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 5)
            {
                btnDeck5.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 6)
            {
                btnDeck6.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 7)
            {
                btnDeck7.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 8)
            {
                btnDeck8.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 9)
            {
                btnDeck9.IsEnabled = true;
            }
            if (cartaScoperta.Valore == 10)
            {
                btnDeck10.IsEnabled = true;
            }
        }
    
        public void RefreshImages()
        {
            string percorso = @"Images\RETRO.jpg";
            imgDiscoveredCard.Source = null;
            if (gioco.Mazzo.Mazzetti[1].MazzoCompletato == false) { imgDeck1.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck1.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[1].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[2].MazzoCompletato == false) { imgDeck2.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck2.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[2].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[3].MazzoCompletato == false) { imgDeck3.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck3.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[3].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[4].MazzoCompletato == false) { imgDeck4.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck4.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[4].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[5].MazzoCompletato == false) { imgDeck5.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck5.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[5].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[6].MazzoCompletato == false) { imgDeck6.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck6.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[6].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[7].MazzoCompletato == false) { imgDeck7.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck7.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[7].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[8].MazzoCompletato == false) { imgDeck8.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck8.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[8].Carte[0].PercorsoCarta, UriKind.Relative)); }
            if (gioco.Mazzo.Mazzetti[9].MazzoCompletato == false) { imgDeck9.Source = new BitmapImage(new Uri(percorso, UriKind.Relative)); }
            else { imgDeck9.Source = new BitmapImage(new Uri(gioco.Mazzo.Mazzetti[9].Carte[0].PercorsoCarta, UriKind.Relative)); }

        }

        public void NormalBtnFun()
        {

        }
        public void ShowCard(Image image)
        {
            string percorso = cartaScoperta.PercorsoCarta;
            image.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            
        }

        
        private void btnDeck1_Click(object sender, RoutedEventArgs e)
        {

            RefreshImages();
            if (gioco.Mazzo.Mazzetti[1].MazzoCompletato==false) 
            {
                if (gioco.Mazzo.Mazzetti[1].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[1].EstraiPrimaCarta();
                    ShowCard(imgDeck1);
                    btnDeck1.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else 
            { 
                btnDeck1.IsEnabled=false;
            }
            gioco.AggiornaSituazionePartita();
            if(gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }


        }
        private void btnDeck2_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[2].MazzoCompletato == false)
            {
                if (gioco.Mazzo.Mazzetti[2].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[2].EstraiPrimaCarta();
                    ShowCard(imgDeck2);
                    btnDeck2.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck2.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }

        private void btnDeck3_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[3].MazzoCompletato == false)
            {
                if (gioco.Mazzo.Mazzetti[3].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[3].EstraiPrimaCarta();
                    ShowCard(imgDeck3);
                    btnDeck3.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck3.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }

        private void btnDeck4_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[4].MazzoCompletato == false)
            {
                if (gioco.Mazzo.Mazzetti[4].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[4].EstraiPrimaCarta();
                    ShowCard(imgDeck4);
                    btnDeck4.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck4.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }

        private void btnDeck5_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[5].MazzoCompletato == false)
            {
                if (gioco.Mazzo.Mazzetti[5].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[5].EstraiPrimaCarta();
                    ShowCard(imgDeck5);
                    btnDeck5.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck5.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }

        }

        private void btnDeck6_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[6].MazzoCompletato == false)
            {
                if (gioco.Mazzo.Mazzetti[6].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[6].EstraiPrimaCarta();
                    ShowCard(imgDeck6);
                    btnDeck6.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck6.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }
        private void btnDeck7_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[7].MazzoCompletato == false)
            {
                if (gioco.Mazzo.Mazzetti[7].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[7].EstraiPrimaCarta();
                    ShowCard(imgDeck7);
                    btnDeck7.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck7.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }

        private void btnDeck8_Click(object sender, RoutedEventArgs e)
        {
            RefreshImages();
            if (gioco.Mazzo.Mazzetti[8].MazzoCompletato == false)
            {
                
                if (gioco.Mazzo.Mazzetti[8].AggiungiCartaConValoreCorretto(cartaScoperta))
                {
                    cartaScoperta = gioco.Mazzo.Mazzetti[8].EstraiPrimaCarta();
                    ShowCard(imgDeck8);
                    btnDeck8.IsEnabled = false;
                    EnableCorrectButton(cartaScoperta);
                }
            }
            else
            {
                btnDeck8.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }

        private void btnDeck9_Click(object sender, RoutedEventArgs e)
        {

            RefreshImages();
            if (gioco.Mazzo.Mazzetti[9].AggiungiCartaConValoreCorretto(cartaScoperta))
            {
                cartaScoperta = gioco.Mazzo.Mazzetti[9].EstraiPrimaCarta();
                ShowCard(imgDeck9);
                btnDeck9.IsEnabled = false;
                EnableCorrectButton(cartaScoperta);
            }
            if (gioco.Mazzo.Mazzetti[9].MazzoCompletato == true)
            {
                btnDeck9.IsEnabled = false;
            }
            gioco.AggiornaSituazionePartita();
            if (gioco.CondizionePartita == CondizionePartita.Vittoria)
            {
                Vittoria();
            }
        }

        private void btnDeck10_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RefreshImages();
                gioco.AggiornaSituazionePartita();
                imgDeck10.Visibility = Visibility.Visible;
                if (gioco.CondizionePartita == CondizionePartita.In_Corso)
                {
                    if (gioco.Mazzo.Mazzetti[10].AggiungiCartaConValoreCorretto(cartaScoperta))
                    {
                        ShowCard(imgDeck10);
                        btnDeck10.IsEnabled = false;
                        btnDeck.IsEnabled = true;
                    }
                }
                gioco.AggiornaSituazionePartita();
                if (gioco.CondizionePartita == CondizionePartita.Vittoria)
                {
                    Vittoria();
                    btnDeck10.IsEnabled = true;
                }
                if (gioco.CondizionePartita == CondizionePartita.Sconfitta)
                {
                    btnReplay.Visibility = Visibility.Visible;
                    lblWin.Content = "Hai \nPerso";
                    lblWin.Visibility = Visibility.Visible;
                    btnDeck10.IsEnabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
            
        }

        private void btnReplay_Click(object sender, RoutedEventArgs e)
        {
            btnReplay.Visibility = Visibility.Collapsed;
            string percorso = @"Images\RETRO.jpg";

            lblWin.Visibility= Visibility.Collapsed;

            imgDeck.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck1.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck2.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck3.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck4.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck5.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck6.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck7.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck8.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck9.Source = new BitmapImage(new Uri(percorso, UriKind.Relative));
            imgDeck10.Visibility = Visibility.Hidden;
            btnDeck1.IsEnabled = false;
            btnDeck2.IsEnabled = false;
            btnDeck3.IsEnabled = false;
            btnDeck4.IsEnabled = false;
            btnDeck5.IsEnabled = false;
            btnDeck6.IsEnabled = false;
            btnDeck7.IsEnabled = false;
            btnDeck8.IsEnabled = false;
            btnDeck9.IsEnabled = false;
            gioco=new Gioco();
        }
        private void Vittoria()
        {
            btnReplay.Visibility = Visibility.Visible;
            lblWin.Content = "Hai \nVinto";
            lblWin.Visibility = Visibility.Visible;
            btnDeck10.IsEnabled = true;
        }
    }
}
