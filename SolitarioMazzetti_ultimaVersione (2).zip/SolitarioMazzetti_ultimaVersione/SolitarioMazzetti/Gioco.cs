﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitarioMazzetti
{
    public enum CondizionePartita
    {
        Vittoria,
        Sconfitta,
        In_Corso
    }
    public class Gioco
    {
        private MazzoPrincipale _mazzo;
        private CondizionePartita _condizionePartita;

        public CondizionePartita CondizionePartita
        {
            get { return _condizionePartita; }
            private set
            {
                if ((int)value < 0 || (int)value > 2) throw new ArgumentException("condizione partita non accettabile");
                _condizionePartita = value;
            }
        }
        public MazzoPrincipale Mazzo
        {
            get { return _mazzo; }
        }
        public Gioco()
        {
            _mazzo = new MazzoPrincipale();
            CondizionePartita = CondizionePartita.In_Corso;
        }
        public void AggiornaSituazionePartita()
        {

            if (_mazzo.Vittoria())
            {
                _condizionePartita = CondizionePartita.Vittoria;
            }
            else if (_mazzo.Sconfitta())
            {
                _condizionePartita = CondizionePartita.Sconfitta;
            }
            else
            {
                _condizionePartita = CondizionePartita.In_Corso;
            }
        }

        /*public void AggiungiCartaMazzettoCorretto(Carta c)
        {
            for (int i = 0; i < _mazzo.Mazzetti.Count; i++)
            {
                try
                {
                    //se non va in errore esco dal ciclo
                    _mazzo.Mazzetti[i].AggiungiCartaConValoreCorretto(c);
                    break;
                }
                catch (Exception)
                {
                    //se va in errore continuo il ciclo
                    continue;
                }
            }
        }*/
    }
}
