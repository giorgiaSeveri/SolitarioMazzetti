﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitarioMazzetti
{
    public enum Semi
    {
        A,//bastoni
        B,//spade
        C,//coppe
        D//denara
    }
    public class Carta
    {
        private int _valore;
        private Semi _seme;
        private bool _cartaCoperta;
        private string _percorsoCarta;

        public string PercorsoCarta
        {
            get { return _percorsoCarta; }
            private set { _percorsoCarta = value; }
        }

        public Semi Seme
        {
            get { return _seme; }
            set
            {
                if ((int)value < 0 || (int)value > 3) throw new ArgumentOutOfRangeException("il seme non è accettabile");
                _seme = value;
            }
        }
        public int Valore
        {
            get { return _valore; }
            set
            {
                if (value < 0 || value > 10) throw new ArgumentOutOfRangeException("il valore non è accettabile");
                _valore = value;
            }
        }
        // false= coperta
        public bool CartaCoperta
        {
            get { return _cartaCoperta; }
            set
            {
                _cartaCoperta = value;
            }
        }
        public void GiraCarta()
        {
            if (CartaCoperta == true)
            {
                CartaCoperta = false;
            }
            else
            {
                CartaCoperta = true;
            }
        }
        public Carta(int valore, Semi seme)
        {
            Valore = valore;
            Seme = seme;
            CartaCoperta = false;
            PercorsoCarta = $"Images/{Valore}" + $"{Seme}" + ".jpg";
        }
    }
}
