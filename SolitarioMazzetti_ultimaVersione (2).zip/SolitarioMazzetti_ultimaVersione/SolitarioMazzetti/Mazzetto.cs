﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitarioMazzetti
{
    public class Mazzetto
    {
        private List<Carta> _carte;
        private int _indice;

        public List<Carta> Carte
        {
            get { return _carte; }
        }
        public int Indice
        {
            get { return _indice; }
            set
            {
                if (value < 0 || value > 10) throw new ArgumentOutOfRangeException("non esiste un mazzetto con questo indice");
                _indice = value;
            }
        }
        public bool MazzoCompletato
        {
            get
            {
                if (Carte.Count == 4)
                {
                    for (int i = 0; i < Carte.Count; i++)
                    {
                        if (Carte[i].Valore != Indice)
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    return false;
                }
                return true;
            }
            
        }
        public Mazzetto(int indice)
        {
            Indice = indice;
            _carte = new List<Carta>();
        }
        //controlla se il valore della carta da aggiungere è uguale a quello del mazzetto
        private bool ControllaUguaglianzaValore(Carta c)
        {
            bool uguaglianzaValore = true;
            if (c.Valore != Indice)
            {
                uguaglianzaValore = false;
            }
            return uguaglianzaValore;
        }

        public void AggiungiInizialmenteCarta(Carta c)
        {
            _carte.Add(c);
        }
        //se la carta è uguale al valore la aggiungo se no mando un errore
        public bool AggiungiCartaConValoreCorretto(Carta carta)
        {
            bool cartaAggiunta = false;

            if (ControllaUguaglianzaValore(carta) == true)
            {
                _carte.Add(carta);
                cartaAggiunta = true;
            }
            return cartaAggiunta;
        }

        

        // rimuovi la prima carta e riodini il mazzetto
        public Carta EstraiPrimaCarta()
        {
            
            Carta primaCarta = _carte[0];
            _carte[0].GiraCarta();
            _carte.Remove(_carte[0]);
            return primaCarta;
        }


    }
}
